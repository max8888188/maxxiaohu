import 'package:logger/logger.dart';

final logs = Logger();
