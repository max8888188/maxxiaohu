import 'package:flutter/widgets.dart';

class BBIcons {
  BBIcons._();

  static const _kFontFam = 'BBIcons';
  static const String? _kFontPkg = null;

  static const IconData github = IconData(
    0xf09b,
    fontFamily: _kFontFam,
    fontPackage: _kFontPkg,
  );
}
