import 'package:flutter/material.dart';

class SettingModel extends ChangeNotifier {
  // 歌单广场源
  List<String> openMusicOrderOrigin = [];

  // 歌单同步源
}
