class GithubOriginConst {
  static String name = 'github';
  static String cname = 'GitHub';
  // static String cacheKeyRepoUrl = 'umo_github_repo_url';
  // static String cacheKeyBranch = 'umo_github_branch';
  // static String cacheKeyToken = 'umo_github_token';
  // static String cacheKeyFilepath = 'umo_github_filepath';

  static String configFieldRepoUrl = 'repo_url';
  static String configFieldBranch = 'branch';
  static String configFieldToken = 'token';
  static String configFieldFilepath = 'filepath';
}
