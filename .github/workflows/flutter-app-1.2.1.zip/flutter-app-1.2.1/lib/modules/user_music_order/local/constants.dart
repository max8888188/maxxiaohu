class LocalOriginConst {
  static String name = 'local';
  static String cname = '本地';
  static String cacheKey = 'umo_local';
}
