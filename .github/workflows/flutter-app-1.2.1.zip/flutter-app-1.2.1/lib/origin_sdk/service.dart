import 'package:bbmusic/origin_sdk/bili/client.dart';

var service = BiliClient();
